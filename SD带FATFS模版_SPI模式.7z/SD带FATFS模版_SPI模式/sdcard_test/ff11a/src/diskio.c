/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2014        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control modules to the FatFs module with a defined API.       */
/*-----------------------------------------------------------------------*/

#include "diskio.h"		/* FatFs lower layer API */
//#include "usbdisk.h"	/* Example: Header file of existing USB MSD control module */
//#include "atadrive.h"	/* Example: Header file of existing ATA harddisk control module */
//#include "sdcard.h"		/* Example: Header file of existing MMC/SDC contorl module */
#include "SDCard.h"
#include "stdio.h"
/* Definitions of physical drive number for each drive */
#define ATA		0	/* Example: Map ATA harddisk to physical drive 0 */
#define MMC		1	/* Example: Map MMC/SD card to physical drive 1 */
#define USB		2	/* Example: Map USB MSD to physical drive 2 */
#define SD		3 /*--ʹ�õ�ʱ����д��ʽ��"3:"������--*/

/*˽�ж���/����------------------------------*/
#define BLOCK_SIZE                512
/*-------------------------------------------*/



/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{
	DSTATUS stat=STA_NOINIT;
//	int result;

	switch (pdrv) {
    case SD :
      	stat = RES_OK;
      return stat;
	case ATA :

		return stat;

	case MMC :

		return stat;

	case USB :
    
		return stat;
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber to identify the drive */
)
{
	DSTATUS stat=STA_NOINIT;
//	int result;

	switch (pdrv) {
  case SD :
      stat=SD_Init();
      if(stat==0x00)
        user_SDCard_printf("��ʼ�����");
      else
        user_SDCard_printf("��ʼ������");
      return stat;
	case ATA :

		return stat;

	case MMC :

		return stat;

	case USB :

		return stat;
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address in LBA */
	UINT count		/* Number of sectors to read */
)
{
	DRESULT res=RES_PARERR;
	int result;

	switch (pdrv) {
  case SD :
    if(count==1)
    {
      result=SD_ReadSingleBlock(sector,buff);
    }
    else
    {
      result=SD_ReadMultiBlock(sector, buff, count);
    }
    if(result==0x00)
    {
      res = RES_OK;
      user_SDCard_printf("��ȡ����");
    }
    else
    {
      res = RES_ERROR;
      user_SDCard_printf("��ȡʧ��");
    }
      return res;
	case ATA :

		return res;

	case MMC :

		return res;

	case USB :

		return res;
	}

	return RES_PARERR;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

#if _USE_WRITE
DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address in LBA */
	UINT count			/* Number of sectors to write */
)
{
	DRESULT res=RES_PARERR;
	int result;

	switch (pdrv) {
  case SD :
    if(count==1)
    {
      result=SD_WriteSingleBlock(sector, buff);
    }
    else
    {
      result=SD_WriteMultiBlock( sector, buff, count);
    }
    if(result==0)
    {
      res = RES_OK;
      user_SDCard_printf("д������");
    }
    else
    {
      res = RES_ERROR;
      user_SDCard_printf("д��ʧ��");
    }
    return res;
	case ATA :

		return res;

	case MMC :

		return res;

	case USB :

		return res;
	}

	return RES_PARERR;
}
#endif


/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

#if _USE_IOCTL
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	DRESULT res=RES_PARERR;
//	int result;
  uint8_t CSD[16] = {0};
	uint8_t csddata[16] = {0};
	uint32_t csize;
	uint32_t Capacity;
  
	switch (pdrv) {
  case SD :
//  if (Stat & STA_NOINIT) return RES_NOTRDY;
//  
//  switch (cmd)
//  {
//  /* Make sure that no pending write process */
//  case CTRL_SYNC :
//			FLASH_SPI_CS_ENABLE();
//			if(SD_WaitReady()==0)
//			{
//					res = RES_OK;
//			}
//			else
//			{
//					res = RES_ERROR;
//			}
//			FLASH_SPI_CSDISABLE();
//    break;
//  
//  /* ��ȡSD����������Ŀ(DWORD) */
//  case GET_SECTOR_COUNT :
//			*(WORD*)buff = 512;
//			res = RES_OK;
//    break;
//  
//  /* ��ȡ��д������С(WORD) */
//  case GET_SECTOR_SIZE :
//			*(DWORD*)buff = SD_GetCapacity();
//			res = RES_OK;
//    break;
//  
//  /* ��ȡ�������С(DWORD) */
//  case GET_BLOCK_SIZE :
//    *(DWORD*)buff = BLOCK_SIZE;
//    break;
//  
//  default:
//    res = RES_PARERR;
//  }

    switch (cmd)
    {
    case CTRL_SYNC:
        res = RES_OK;
        break;
    case GET_SECTOR_COUNT:
				SD_GetCID(CSD);
				SD_GetCSD(csddata);
//			SDGetCIDCSD(CSD, csddata);
			  csize = csddata[9] + ((uint32_t)csddata[8] << 8) + ((uint32_t)(csddata[7] & 0x3f) << 16) + 1;
			  Capacity = csize << 9;
        *((DWORD *)buff) = Capacity;
        res = RES_OK;
        break;
    case GET_SECTOR_SIZE:
        *(WORD *)buff = 512; //spi flash��������С�� 512 Bytes
        return RES_OK;
    case GET_BLOCK_SIZE:
        *((DWORD *)buff) = 4096;
        res = RES_OK;
        break;
    default:
        res = RES_PARERR;
        break;
    }

      return res;
	case ATA :

		return res;

	case MMC :

		return res;

	case USB :

		return res;
	}

	return RES_PARERR;
}
#endif
DWORD get_fattime (void)
{
  return 0;
}
